<h1>Entrega do AppQuarta - Atividade de Classes</h1>

<p>O <strong>AppQuarta</strong> é uma aplicação web desenvolvida em ASP.NET Core (MVC) para ensinar a utilização de classes e restrições de seu atrubutos. </p>
